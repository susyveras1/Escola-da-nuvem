# Solicita o nome do usuário
nome = input("Digite seu nome: ")

# Exibe uma mensagem de boas-vindas
print(f"Olá, {nome}! Seja bem-vindo(a) ao Python! 👋")