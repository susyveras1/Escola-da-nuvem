# Passo 1: pedir ao usuario pra inserir 2 num

num1 = int(input('Digite o primeiro numero: '))
num2 = int(input('Digite o segundo numero: '))

# Passo 2: Soma
soma = num1 + num2

# Passo 3: Multiplicação
multi = num1 * num2

# Passo 4: Resultado
print(f'A soma entre {num1} e {num2} é igual a {soma}') 
print(f'A multiplicação entre {num1} e {num2} é igual a {multi}')