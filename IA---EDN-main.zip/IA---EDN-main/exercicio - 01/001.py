# 1 - Crie um programa em Python que peça dois números ao usuário, some esses valores e exiba o resultado na tela.

# Solicitar os dois números ao usuário
numero1 = float(input("Digite o primeiro número: "))
numero2 = float(input("Digite o segundo número: "))

# Somar os números
soma = numero1 + numero2

# Exibir o resultado
print(f"A soma de {numero1} e {numero2} é: {soma}")
