# 003 - Crie um programa em Python que utilize um laço for para exibir os números de 1 a 10 na tela.

for numero in range(1, 11):
    print(numero)