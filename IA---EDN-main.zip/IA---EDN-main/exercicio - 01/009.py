# 009 - Crie um programa que faça uma contagem regressiva de 5 até 1 usando while, e exiba “Lançar!” no final.

# Inicia a contagem regressiva
contador = 5

# Laço while para a contagem regressiva
while contador > 0:
    print(contador)
    contador -= 1

# Exibe "Lançar!" no final
print("Lançar!")
